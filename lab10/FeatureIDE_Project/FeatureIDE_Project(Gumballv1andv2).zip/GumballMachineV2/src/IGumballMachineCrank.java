
public interface IGumballMachineCrank {
	public void insertQuarter() ;
	public void turnTheCrank() ;
}
