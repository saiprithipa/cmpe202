
public interface IGumballMachineSlot {
	public void insertCoin( int value ) ;
	public void returnCoins( ) ;
}
